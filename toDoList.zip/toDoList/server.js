const express = require("express");
const bodyPraser = require("body-parser");
const ejs = require("ejs");
const app = express();
app.set('view engine', ejs);
app.use(bodyPraser.urlencoded({extended: true}));
app.set('view engine', ejs);


app.get('/', (request, response) => {
    let today = new Date();
    let day = "";
 
    if(today.getDay() === 6 || today.getDay() === 0) {
        day = 'Weekend';
        
    } else {
        day = 'Workday';
    }
    console.log("test");
    response.render('data.ejs', {kindOfDay: day});
});



app.listen(3000, () => {
    console.log("Server is running on Port 3000");

});