var superheroes = require('superheroes');
var Superman = superheroes.random();
console.log(Superman);

var supervillains = require('supervillains');
var Joker = supervillains.random();
console.log(Joker);